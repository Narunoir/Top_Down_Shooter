import pygame as pg, pygame
import random
from random import uniform, choice, randint
from settings import *
from tilemap import *
import pytweening as tween
from itertools import chain
import math
from pygame.math import Vector2


def collide_with_walls(sprite, group, dir):
    hits = pg.sprite.spritecollide(sprite, group, False, collide_hit_rect)
    if not hits:
        return

    wall = hits[0]

    if dir == 'x':
        if sprite.vel.x > 0:  # moving right
            overlap = sprite.hit_rect.right - wall.rect.left
            sprite.hit_rect.right -= overlap
        elif sprite.vel.x < 0:  # moving left
            overlap = wall.rect.right - sprite.hit_rect.left
            sprite.hit_rect.left += overlap
        sprite.vel.x = 0

    elif dir == 'y':
        if sprite.vel.y > 0:  # moving down
            overlap = sprite.hit_rect.bottom - wall.rect.top
            sprite.hit_rect.bottom -= overlap
        elif sprite.vel.y < 0:  # moving up
            overlap = wall.rect.bottom - sprite.hit_rect.top
            sprite.hit_rect.top += overlap
        sprite.vel.y = 0



class Player(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        super().__init__(game.all_sprites)
        self.game = game
        self.image = game.player_img
        self.rect = self.image.get_rect(center=(x, y))
        self.hit_rect = PLAYER_HIT_RECT.copy()
        self.hit_rect.center = self.rect.center
        self.pos = vec(x, y)
        self.vel = vec(0, 0)
        self.rot = 0

        self.health = PLAYER_HEALTH
        self.weapon = 'pistol'
        self.grenade = 'grenade'
        self.has_weapons = {
            'pistol': True,
            'shotgun': True,
            'flamethrower': True,
            'bazooka': True,
            'grenade': True
        }
        self.weapon_images = {
            'pistol': game.player_img_gun,
            'shotgun': game.player_img_shotgun,
            'flamethrower': game.player_img_flamethrower,
            'bazooka': game.player_img_bazooka
        }

        self.grenade_count = 1
        self.last_shot = 0
        self.dot_effect = []
        self.distance = 0
        self.damaged = False
        self.is_stunned = False
        self.stun_start_time = 0
        self.last_vibration_time = 0
        self.tween = tween.easeInOutSine
        self.step = 0
        self.dir = 1

    def get_keys(self):
        self.vel = vec(0, 0)
        keys = pg.key.get_pressed()
        mouse = pg.mouse.get_pressed()

        if (mouse[0] or keys[pg.K_w]):
            self.vel = vec(PLAYER_SPEED, 0).rotate(-self.rot)
        elif keys[pg.K_DOWN] or keys[pg.K_s]:
            self.vel = vec(-PLAYER_SPEED / 2, 0).rotate(-self.rot)

        if keys[pg.K_SPACE] or mouse[2]:
            self.shoot()

        weapon_keys = {pg.K_1: 'pistol', pg.K_2: 'shotgun', pg.K_3: 'flamethrower', pg.K_4: 'bazooka'}
        for k, name in weapon_keys.items():
            if keys[k] and self.has_weapons[name]:
                self.weapon = name
                self.game.player_img = self.weapon_images[name]

        if keys[pg.K_e] or mouse[1]:
            if self.has_weapons['grenade']:
                last = self.weapon
                self.weapon = 'grenade'
                self.throw_grenade()
                self.weapon = last

    def shoot(self):
        if self.is_stunned:
            return
        now = pg.time.get_ticks()
        if now - self.last_shot < WEAPONS[self.weapon]['fireing_rate']:
            return
        self.last_shot = now
        dir = vec(1, 0).rotate(-self.rot)
        pos = self.pos + BARREL_OFFSET.rotate(-self.rot)
        self.vel = vec(-WEAPONS[self.weapon]['kickback'], 0).rotate(-self.rot)

        for _ in range(WEAPONS[self.weapon]['bullet_count']):
            spread = uniform(-WEAPONS[self.weapon]['gun_spread'], WEAPONS[self.weapon]['gun_spread'])
            angle = dir.rotate(spread)
            damage = WEAPONS[self.weapon]['bullet_damage']

            if self.weapon == 'bazooka':
                Rocket(self.game, pos, angle, damage, 200)
            elif self.weapon == 'flamethrower':
                Flame(self.game, pos, angle, damage, 20)
            else:
                Bullet(self.game, pos, angle, damage)

        snd = choice(self.game.weapon_sounds[self.weapon])
        if snd.get_num_channels() > 2:
            snd.stop()
        snd.play()
        MuzzleFlash(self.game, pos)

    def throw_grenade(self):
        if self.grenade_count <= 0:
            return
        now = pg.time.get_ticks()
        if now - self.last_shot < WEAPONS[self.weapon]['fireing_rate']:
            return
        self.last_shot = now

        dir = vec(1, 0).rotate(-self.rot)
        pos = self.pos + BARREL_OFFSET.rotate(-self.rot)
        self.vel = vec(-WEAPONS[self.weapon]['kickback'], 0).rotate(-self.rot)

        for _ in range(WEAPONS[self.weapon]['bullet_count']):
            spread = uniform(-WEAPONS[self.weapon]['gun_spread'], WEAPONS[self.weapon]['gun_spread'])
            angle = dir.rotate(spread)
            Grenade(self.game, pos, angle, WEAPONS[self.weapon]['bullet_damage'], 500)

        snd = choice(self.game.weapon_sounds[self.weapon])
        if snd.get_num_channels() > 2:
            snd.stop()
        snd.play()

    def apply_dot(self, dot_effect):
        self.dot_effect.append(dot_effect)

    def got_hit(self):
        self.damaged = True
        self.damage_alpha = chain(DAMAGE_ALPHA * 2)

    def stunned_effect(self):
        now = pg.time.get_ticks()
        if self.stun_start_time == 0:
            self.stun_start_time = now
            self.vel = vec(0, 0)
        elif now - self.stun_start_time > 1000:
            self.is_stunned = False
            self.stun_start_time = 0
        self.vibration()

    def move_and_collide(self, dt=None):
        if dt is None:
            dt = self.game.dt

        # --- X axis ---
        self.pos.x += self.vel.x * dt
        self.hit_rect.centerx = self.pos.x
        collide_with_walls(self, self.game.walls, 'x')
        self.pos.x = self.hit_rect.centerx

        # --- Y axis ---
        self.pos.y += self.vel.y * dt
        self.hit_rect.centery = self.pos.y
        collide_with_walls(self, self.game.walls, 'y')
        self.pos.y = self.hit_rect.centery

        # --- Mouse rotation ---
        mx, my = pg.mouse.get_pos()
        cam_x, cam_y = self.game.camera.camera.topleft
        world_mx = mx - cam_x
        world_my = my - cam_y

        dx, dy = world_mx - self.pos.x, world_my - self.pos.y
        self.distance = math.hypot(dx, dy)

        if self.distance > ROTATE_DEADZONE:
            self.rot = math.degrees(-math.atan2(dy, dx))

        # --- Rotate image and update rect ---
        rotated_img = pg.transform.rotate(self.game.player_img, int(self.rot))
        self.image = rotated_img
        self.rect = rotated_img.get_rect(center=(self.pos.x, self.pos.y))


    def vibration(self):
        offset = 10 * (self.tween(self.step / 10) - 0.5)
        self.rect.centery = self.pos.y + offset * self.dir
        self.step += 3.5
        if self.step > 10:
            self.step = 0
            self.dir *= -1
            self.move_and_collide()

    def add_health(self, amount):
        self.health = min(self.health + amount, PLAYER_HEALTH)

    def update(self):
        if self.is_stunned:
            self.stunned_effect()
            return

        # 1. Input & velocity
        self.get_keys()

        # 2. Movement, collision, and rotation (all in one place now)
        self.move_and_collide()

        # 3. Damage flash (if any)
        if self.damaged:
            try:
                alpha = next(self.damage_alpha)
                self.image.fill((255, 0, 0, alpha),
                                special_flags=pg.BLEND_RGBA_MULT)
            except StopIteration:
                self.damaged = False       




class Mob(pg.sprite.Sprite):
    def __init__(self, game, x, y, mob_type, map_obj=None, player=None, wall_group=None):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs
        super().__init__(game.all_sprites, game.mobs, self.groups)
        map_obj    = map_obj    or game.map
        player     = player     or game.player
        wall_group = wall_group or game.walls

        self._hp_bar_surf = pg.Surface((1, 7)).convert_alpha()
        self.game      = game
        self.base_img  = game.mob_img[mob_type]
        self.image     = self.base_img.copy()
        self.rect      = self.image.get_rect(center=(x, y))
        self.hit_rect  = self.rect.copy()

        self.pos       = Vector2(x, y)
        self.vel       = Vector2(0, 0)
        self.acc       = Vector2(0, 0)
        self.rot       = 0

        self.mob_type  = mob_type
        self.health    = MOB_HEALTH
        self.speed     = choice(MOB_SPEEDS)
        self.target    = game.player
        self.grid      = game.map.grid
        self.wall_group= game.walls
        self.dot_effect= []
        # Pre-generate rotated images (optional)
        self.rot_images = {
            angle: pg.transform.rotate(self.base_img, angle)
            for angle in range(0, 360, 22)
        }

    def apply_dot(self, dot):
        self.dot_effect.append(dot)

    def avoid_mobs(self):
        for mob in self.game.mobs:
            if mob is not self:
                dist = self.pos - mob.pos
                if 0 < dist.length() < AVOID_RADIUS:
                    self.acc += dist.normalize()

    def update(self):
        dt = self.game.dt

        # Detection and movement
        target_dist = self.target.pos - self.pos
        if target_dist.length_squared() < ENGAGE_RADIUS**2:
            if random.random() < 0.002:
                choice(self.game.zombie_moan_sounds).play()

            # Rotate toward player
            self.rot = target_dist.angle_to(Vector2(1, 0))
            self.image = self.rot_images.get(int(self.rot), self.base_img)

            # Acceleration toward player
            self.acc = target_dist.normalize() * self.speed - self.vel
            self.vel += self.acc * dt

            # --- X axis movement ---
            self.pos.x += self.vel.x * dt
            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.wall_group, 'x')
            self.pos.x = self.hit_rect.centerx

            # --- Y axis movement ---
            self.pos.y += self.vel.y * dt
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.wall_group, 'y')
            self.pos.y = self.hit_rect.centery

            # Sync draw rect
            self.rect.center = self.hit_rect.center

        # Process DoT in-place
        for i in reversed(range(len(self.dot_effect))):
            dmg = self.dot_effect[i].update(dt)
            self.health -= dmg or 0
            if self.dot_effect[i].duration <= 0:
                self.dot_effect.pop(i)

        # Death check
        if self.health <= 0:
            self.kill()
            self.game.score += 50
            self.game.exp += 3

    def draw_health(self):
        if self.health >= MOB_HEALTH:
            return
        width = max(0,int(self.rect.width * self.health / MOB_HEALTH))
        col   = GREEN if self.health>60 else YELLOW if self.health>30 else RED
        self._hp_bar_surf.fill(col)
        hp_surf = pg.transform.scale(self._hp_bar_surf, (width, 7))
        self.image.blit(hp_surf, (0, 0))


class Boss(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs, game.boss
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.boss_level = self.game.current_level
        self.image = game.boss_image[self.boss_level].copy()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.hit_rect = BOSS[self.boss_level]['boss_hit_rect'].copy()
        self.hit_rect.center = self.rect.center
        self.pos = vec(x, y)
        self.vel = vec(0, 0)
        self.acc = vec(0, 0)
        self.rect.center = self.pos
        self.rot = 0
        self.is_boss = True
        self.damaged = False
        self.health = BOSS[self.game.current_level]['boss_health']
        self.speed = BOSS[self.game.current_level]['boss_speed']
        self.target = game.player
        self.dot_effect = []
        

    def avoid_mobs(self):
        for mob in self.game.mobs:
            if mob != self:
                dist = self.pos - mob.pos
                if 0 < dist.length() < AVOID_RADIUS:
                    self.acc += dist.normalize()
    
    def got_hit(self):
        self.damaged = True
        self.damage_alpha = chain(DAMAGE_ALPHA * 2)

    def apply_dot(self, dot_effect):
        self.dot_effect.append(dot_effect)

    def face_player(self):
        player_dist = self.target.pos - self.pos
        self.rot = player_dist.angle_to(vec(1, 0))    
        self.image = pg.transform.rotate(self.game.boss_image[self.boss_level], self.rot)
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
    
    
    
    def update(self):
        player_dist = self.target.pos - self.pos
        if self.damaged:
            try:
                self.image.fill((255, 0, 0, next(self.damage_alpha)), special_flags=pg.BLEND_RGBA_MULT)
            except:
                self.damaged = False
        if player_dist.length_squared() < ENGAGE_RADIUS**2:  # Adjusted exponent to 2 for a realistic radius
            if random.random() < 0.002:
                choice(self.game.zombie_moan_sounds).play()
            self.face_player()  # Call the new method to face the player
            self.acc = vec(1, 0.01).rotate(-self.rot)
            self.acc.scale_to_length(self.speed)
            self.avoid_mobs()
            self.acc += self.vel * -1
            self.vel += self.acc * self.game.dt
            self.pos += self.vel * self.game.dt + 0.5 * self.acc * self.game.dt ** 2
            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.game.walls, 'y')
            self.rect.center = self.pos.xy
        
            # Process DoT effects
        for dot_effect in self.dot_effect[:]:  # Iterate over a copy of the list
            damage = dot_effect.update(self.game.dt)
            if damage:
                self.health -= damage
            if dot_effect.duration <= 0:
                self.dot_effect.remove(dot_effect)  # Remove expired DoT effects
        
        
        if self.health <= 0:
            choice(self.game.zombie_hit_sounds).play()
            self.kill()
            self.game.map_img.blit(self.game.splat, self.pos - vec(32, 32))
            self.game.score += 200
            self.game.player.exp += 50


                   
    

class Bullet(pg.sprite.Sprite):
    def __init__(self, game, pos, dir, damage):
        self._layer = BULLET_LAYER
        self.groups = game.all_sprites, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.bullet_images[WEAPONS[game.player.weapon]['bullet_image']]
        self.rect = self.image.get_rect()
        self.hit_rect = self.rect
        self.pos = vec(pos)
        self.rect.center = pos
        #spread = uniform(-GUN_SPREAD, GUN_SPREAD)
        self.vel = dir * WEAPONS[game.player.weapon]['bullet_speed'] * uniform(0.9, 1.1)
        #self.vel = dir * BULLET_SPEED
        self.spawn_time = pg.time.get_ticks()
        self.damage = damage


    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        if pg.sprite.spritecollideany(self,self.game.walls):
            self.kill()
        if pg.time.get_ticks() - self.spawn_time > WEAPONS[self.game.player.weapon]['bullet_lifetime']:
            self.kill()

class Rocket(pg.sprite.Sprite):
    def __init__(self, game, pos, dir, damage, explosion_size):
        self._layer = BULLET_LAYER
        self.groups = game.all_sprites, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.explosion_size = explosion_size
        self.image = game.bullet_images[WEAPONS[game.player.weapon]['bullet_image']]
        self.rect = self.image.get_rect()
        self.hit_rect = self.rect
        self.pos = vec(pos)
        self.rect.center = pos
        #spread = uniform(-GUN_SPREAD, GUN_SPREAD)
        self.vel = dir * WEAPONS[game.player.weapon]['bullet_speed'] * uniform(0.9, 1.1)
        #self.vel = dir * BULLET_SPEED
        self.spawn_time = pg.time.get_ticks()
        self.damage = damage


    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        if pg.sprite.spritecollideany(self,self.game.walls):
            ####  ADD EXPLODE HERE   #####
            Explosion(self.game, self.pos, self.explosion_size, self.damage)
            self.kill()
        if pg.time.get_ticks() - self.spawn_time > WEAPONS[self.game.player.weapon]['bullet_lifetime']:
            self.kill()

class Flame(pg.sprite.Sprite):
    def __init__(self, game, pos, dir, damage, explosion_size):
        self._layer = BULLET_LAYER
        self.groups = game.all_sprites, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.explosion_size = explosion_size
        self.image = game.bullet_images[WEAPONS[game.player.weapon]['bullet_image']]
        self.rect = self.image.get_rect()
        self.hit_rect = self.rect
        self.pos = vec(pos)
        self.rect.center = pos
        #spread = uniform(-GUN_SPREAD, GUN_SPREAD)
        self.vel = dir * WEAPONS[game.player.weapon]['bullet_speed'] * uniform(0.9, 1.1)
        #self.vel = dir * BULLET_SPEED
        self.spawn_time = pg.time.get_ticks()
        self.damage = damage


    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        if pg.sprite.spritecollideany(self,self.game.walls):
            ####  ADD EXPLODE HERE   #####
            Explosion(self.game, self.pos, self.explosion_size, self.damage)
            self.kill()
        if pg.time.get_ticks() - self.spawn_time > WEAPONS[self.game.player.weapon]['bullet_lifetime']:
            self.kill()

class Grenade(pg.sprite.Sprite):
    def __init__(self, game, pos, dir, damage, explosion_size):
        self._layer = BULLET_LAYER
        self.groups = game.all_sprites, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.explosion_size = explosion_size
        self.image = game.bullet_images[WEAPONS[game.player.weapon]['bullet_image']]
        self.rect = self.image.get_rect()
        self.hit_rect = self.rect
        self.pos = vec(pos)
        self.rect.center = pos
        self.vel = dir * WEAPONS[game.player.weapon]['bullet_speed'] * uniform(0.9, 1.1)
        self.spawn_time = pg.time.get_ticks()
        self.damage = damage
        self.gravity = 2  # adjust this value to change the arc height
        self.has_exploded = False
        

    def update(self):
        if pg.time.get_ticks() - self.spawn_time > WEAPONS[self.game.player.grenade]['grenade_lifetime']:
            self.has_exploded = True
        if self.has_exploded == True:
            Explosion(self.game, self.pos, self.explosion_size, 500)
            self.kill()
            self.has_exploded = False
        self.vel.y += self.gravity  # apply gravity
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        mobs_and_walls = self.game.mobs.copy()
        mobs_and_walls.add(self.game.walls)
        hit = pg.sprite.spritecollideany(self, mobs_and_walls)
        
        if hit:
            # Check which side of the sprite/wall the grenade hit and reverse velocity
            if abs(hit.rect.left - self.rect.right) < 10 and self.vel.x > 0:
                self.vel.x *= -0.25  # reverse and halve the velocity
            if abs(hit.rect.right - self.rect.left) < 10 and self.vel.x < 0:
                self.vel.x *= -0.25  # reverse and halve the velocity
            if abs(hit.rect.top - self.rect.bottom) < 10 and self.vel.y > 0:
                self.vel.y *= -0.25  # reverse and halve the velocity
            if abs(hit.rect.bottom - self.rect.top) < 10 and self.vel.y < 0:
                self.vel.y *= -0.25 # reverse and halve the velocity
            

class Wall(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self._layer = WALL_LAYER
        self.groups = game.all_sprites, game.walls
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.wall_img
        self.rect = self.image.get_rect()
        self.hit_rect = self.rect
        self.x = x
        self.y = y
        self.rect.x = x * TILESIZE
        self.rect.y = y * TILESIZE

class Obstacle(pg.sprite.Sprite):
    def __init__(self, game, x, y, w, h):
        self.groups = game.walls
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.rect = pg.Rect(x, y, w, h)
        self.hit_rect = self.rect
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y

class MuzzleFlash(pg.sprite.Sprite):
    def __init__(self, game, pos):
        self._layer = EFFECTS_LAYER
        self.groups = game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        size = randint(20, 50)
        self.image = pg.transform.scale(choice(game.gun_flashes), (size, size))
        self.rect = self.image.get_rect()
        self.hit_rect = self.rect
        self.pos = pos
        self.rect.center = pos
        self.spawn_time = pg.time.get_ticks()

    def update(self):
        if pg.time.get_ticks() - self.spawn_time > FLASH_DURATION:
           self.kill()

class Explosion(pg.sprite.Sprite):
    def __init__(self, game, pos, size, damage):
        self._layer = EFFECTS_LAYER
        self.groups = game.all_sprites, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.pos = pos
        self.damage = damage
        # Check the player's weapon and adjust the size accordingly
        self.size = size
        self.image = pg.transform.scale(choice(game.gun_flashes), (self.size, self.size))
        self.rect = self.image.get_rect()
        self.rect.center = pos
        self.spawn_time = pg.time.get_ticks()
        self.hit_rect = self.rect

    def update(self):
        if pg.time.get_ticks() - self.spawn_time > EXPLOSION_DURATION:
            self.kill()


class Item(pg.sprite.Sprite):
    def __init__(self, game, pos, type):
        self._layer = ITEMS_LAYER
        self.groups = game.all_sprites, game.items
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.item_images[type]
        self.rect = self.image.get_rect()
        self.type = type
        self.pos = pos
        self.rect.center = pos
        self.hit_rect = self.rect
        self.tween = tween.easeInOutSine
        self.step = 0
        self.dir  = 1

    def update(self):
        ## bobbing motion
        offset = BOB_RANGE * (self.tween(self.step / BOB_RANGE) - 0.5)
        self.rect.centery = self.pos.y + offset * self.dir
        self.step += BOB_SPEED
        if self.step > BOB_RANGE:
            self.step = 0
            self.dir *= -1


## Sprite Template ##   The basic outline of a sprite object.
class Name(pg.sprite.Sprite):
    def __init__(self, game, ):
        self.groups = game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.image = pg.Surface(())
        self.rect = self.image.get_rect()


class DotEffect:
    def __init__(self, game, target, damage_per_tick, duration, tick_rate):
        self._layer = BULLET_LAYER
        self.groups = game.all_sprites, game.bullets, game.mob_bullets
        self.game = game
        self.damage_per_tick = damage_per_tick
        self.duration = duration
        self.tick_rate = tick_rate
        self.elapsed_time = 0
        self.time_since_last_tick = 0
        self.target = target
        

    def apply_damage(self):
        """Apply damage to the target."""
        if self.target.health > 0:  # Check if the target is alive
            self.target.health -= self.damage_per_tick  # Apply damage
            self.effect_position = self.target.rect.center
            #print(f"Applied {self.damage_per_tick} damage to {self.target}. Health is now {self.target.health}.")
            if self.target.health <= 0:  # Check if the target is dead
                pass
    def get_random_position_within_target(self):
        """Generate a random position within the target's rect."""
        random_x = random.randint(self.target.rect.left, self.target.rect.right)
        random_y = random.randint(self.target.rect.top, self.target.rect.bottom)
        return (random_x, random_y)
    
    def update(self, dt):
        """Update the dot effect, applying damage at each tick."""
        self.elapsed_time += dt
        self.time_since_last_tick += dt

        if self.elapsed_time > self.duration:
            self.kill()  # Remove the effect after its duration
        elif self.time_since_last_tick >= self.tick_rate:
            self.apply_damage()  # Apply damage
            random_pos = self.get_random_position_within_target()
            Explosion(self.game, random_pos, 12, 0)
            self.time_since_last_tick = 0  # Reset tick timer


class ZombieBoss(Boss):
    def __init__(self, game, x, y):
        super().__init__(game, x, y)
        self.last_spawn = pg.time.get_ticks()  # Initialize last_spawn with the current time
        self.last_throw = 0  # Initialize last_throw with 0 or current time


    def spawn_zombie(self):
        ZombieMob(self.game, self.pos.x, self.pos.y)

    def spawn_zombies_based_on_health(self):
        health_pct = self.health / BOSS[self.game.current_level]['boss_health']
        now = pg.time.get_ticks()

        if health_pct > 0.7:
            if now - self.last_spawn > 8000:  # Every 8 seconds
                for _ in range(2):  # Spawn 2 zombies
                    self.spawn_zombie()
                self.last_spawn = now
        elif health_pct > 0.4:
            if now - self.last_spawn > 6000:  # Every 6 seconds
                for _ in range(3):  # Spawn 3 zombies
                    self.spawn_zombie()
                self.last_spawn = now
        elif health_pct > 0.1:
            if now - self.last_spawn > 4000:  # Every 4 seconds
                for _ in range(4):  # Spawn 4 zombies
                    self.spawn_zombie()
                self.last_spawn = now
        else:
            if now - self.last_spawn > 2000:  # Every 2 seconds
                for _ in range(5):  # Spawn 5 zombies
                    self.spawn_zombie()
                self.last_spawn = now
    
    def throw_zombie_at_player(self):
        now = pg.time.get_ticks()
        if now - self.last_throw > 9000:  # 9 seconds = 9000 milliseconds
            player_pos = self.target.pos
            mob_pos = self.pos
            mob_to_player = player_pos - mob_pos
            distance_to_player = mob_to_player.length()
            
            if distance_to_player < THROW_RANGE:
                # Launch the zombie towards the player
                mob_to_player.normalize_ip()
                mob_velocity = mob_to_player * THROW_SPEED
                # Create a new zombie at the current position
                new_mob = ZombieMob(self.game, mob_pos.x, mob_pos.y)
                # Set the velocity of the new zombie
                new_mob.vel = mob_velocity
                self.last_throw = now  # Update the last_throw time

    def update(self):
        super().update()
        self.throw_zombie_at_player()
        self.spawn_zombies_based_on_health()

class ScorpionBoss(Boss):
    def __init__(self, game, x, y):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs, game.boss
        super().__init__(game, x, y)
        self.last_shot = 0

    def spit_poison(self):
        now = pg.time.get_ticks()
        if now - self.last_shot > 3000:  
            player_pos = self.target.pos
            mob_pos = self.pos
            mob_to_player = player_pos - mob_pos
            distance_to_player = mob_to_player.length()
            #dir = vec(1, 0).rotate(-self.rot)
            
            if distance_to_player < THROW_RANGE:
                # Launch the poison ball towards the player
                mob_to_player.normalize_ip()
                mob_velocity = mob_to_player * THROW_SPEED
                # Create a new poison ball at the current position
                new_poison_ball = PoisonBall(self.game, mob_pos, 0)
                # Set the velocity of the new poison ball
                new_poison_ball.vel = mob_velocity
                self.last_shot = now  # Update the last_shot time

    def update(self):
        super().update()
        self.spit_poison()

class RobotBoss(Boss):
    def __init__(self, game, x, y):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs, game.boss
        super().__init__(game, x, y)

    def update(self):
        super().update()

class AirportBot(Boss):
    def __init__(self, game, x, y):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs, game.boss
        super().__init__(game, x, y)

    def update(self):
        super().update()

class BusDriver(Boss):
    def __init__(self, game, x, y):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs, game.boss
        super().__init__(game, x, y)

    def update(self):
        super().update()
# Define the LEVEL_BOSS mapping with lambda functions
LEVEL_BOSS = {
    1: lambda game, x, y: ZombieBoss(game, x, y),
    2: lambda game, x, y: ScorpionBoss(game, x, y),
    3: lambda game, x, y: RobotBoss(game, x, y),
    4: lambda game, x, y: AirportBot(game, x, y),
    5: lambda game, x, y: BusDriver(game, x, y),
    # Continue mapping for other levels as needed
}        


class ZombieMob(Mob):
    def __init__(self, game, x, y):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs
        super().__init__(game, x, y, 'zombie_mob', game.map, game.player, game.walls)
        self.engaged = False  # Initialize engaged state
        self.lunge_cooldown = 3000  # Cooldown time in milliseconds
        self.last_lunge_time = 0  # Track the last lunge time
        self.lunge_pause_duration = 500  # Pause for 500ms after lunging
        self.is_lunging = False  # Indicates if currently in lunge-pause state

    def zombie_lunge(self):
        current_time = pygame.time.get_ticks()
        if self.is_lunging:
            # If in lunging state, check if it's time to reset velocity
            if current_time - self.last_lunge_time > self.lunge_pause_duration:
                self.vel = vec(0, 0)  # Stop moving after lunge pause
                self.is_lunging = False  # Reset lunging state
                self.pos += self.vel * self.game.dt
                self.hit_rect.centerx = self.pos.x
                collide_with_walls(self, self.game.walls, 'x')
                self.hit_rect.centery = self.pos.y
                collide_with_walls(self, self.game.walls, 'y')
        else:
            # Check if cooldown has elapsed and it's time to lunge.
            if current_time - self.last_lunge_time > self.lunge_cooldown:
                player_pos = self.target.pos
                mob_pos = self.pos
                mob_to_player = player_pos - mob_pos
                distance_to_player = mob_to_player.length()
                if distance_to_player < 200:
                    mob_to_player.normalize_ip()
                    mob_velocity = mob_to_player * 200
                    self.vel = mob_velocity
                    self.last_lunge_time = current_time
                    self.is_lunging = True  # Enter lunging state
                    self.avoid_walls()  # Avoid walls during lunge

    def avoid_walls(self):
        current_time = pygame.time.get_ticks()
        """Avoid walls during lunge."""
        for wall in self.game.walls:
            if pygame.sprite.collide_rect(self, wall):
                self.vel = vec(0, 0)  # Stop moving if colliding with a wall
                self.is_lunging = False  # Reset lunging state
                break
        else:
            # Check if cooldown has elapsed and it's time to lunge.
            if current_time - self.last_lunge_time > self.lunge_cooldown:
                player_pos = self.target.pos
                mob_pos = self.pos
                mob_to_player = player_pos - mob_pos
                distance_to_player = mob_to_player.length()
                if distance_to_player < 200:
                    mob_to_player.normalize_ip()
                    mob_velocity = mob_to_player * 200
                    self.vel = mob_velocity
                    self.last_lunge_time = current_time
                    self.is_lunging = True  # Enter lunging state
        

    def update(self):
        super().update()
        self.pos += self.vel * self.game.dt
        player_dist = self.target.pos - self.pos
        if player_dist.length_squared() < ENGAGE_RADIUS**2:
            self.zombie_lunge()
            if random.random() < 0.002:
                choice(self.game.zombie_moan_sounds).play()
            self.rot = player_dist.angle_to(vec(1, 0))
            self.image = pg.transform.rotate(self.game.mob_img['zombie_mob'], self.rot)
            self.rect = self.image.get_rect()
            self.rect.center = self.pos
            self.acc = vec(1, 0.01).rotate(-self.rot)
            self.avoid_mobs()
            self.acc.scale_to_length(self.speed)
            self.acc += self.vel * -1
            self.vel += self.acc * self.game.dt
            self.pos += self.vel * self.game.dt + 0.5 *self.acc * self.game.dt ** 2
            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.game.walls, 'y')
            self.rect.center = self.hit_rect.center
        if self.health <= 0:
            choice(self.game.zombie_hit_sounds).play()
            self.game.map_img.blit(self.game.splat, self.pos - vec(32, 32))
            self.kill()
        


class ScorpionMob(Mob):
    def __init__(self, game, x, y):
        super().__init__(game, x, y, 'scorpion_mob')
        self.hit_rect.width *= 0.75
        self.hit_rect.height *= 0.75
        self.last_shot = 0
        self.engage_radius = 600

    def spit_poison(self):
        now = pg.time.get_ticks()
        if now - self.last_shot > 3000:
            distance = (self.target.pos - self.pos).length_squared()
            if distance < self.engage_radius**2:
                direction = (self.target.pos - self.pos).normalize()
                velocity = direction * THROW_SPEED
                ball = PoisonBall(self.game, self.pos, 8, velocity)
                self.last_shot = now

    
    def update(self):
        super().update()
        if (self.target.pos - self.pos).length_squared() < self.engage_radius**2:
            self.spit_poison()

    
        
class PoisonBall(pg.sprite.Sprite):
    def __init__(self, game, pos, damage, velocity):
        super().__init__(game.all_sprites, game.mob_bullets)
        self.game = game
        self.image = game.mob_weapon_images['poison_ball']
        self.rect = self.image.get_rect(center=pos)
        self.hit_rect = self.rect
        self.pos = vec(pos)
        self.damage = damage
        self.spawn_time = pg.time.get_ticks()
        self.duration = 1000
        self.velocity = velocity
        self.target = game.player


    def update(self):
        self.pos += self.velocity * self.game.dt
        self.rect.center = self.pos

        if pg.sprite.collide_rect(self, self.target):
            self.target.health -= self.damage
            self.target.apply_dot(DotEffect(self.game, self.target, 5, 5000, 500))
            PoisonPuddle(self.game, self.pos)
            self.kill()

        elif pg.sprite.spritecollideany(self, self.game.walls):
            PoisonPuddle(self.game, self.pos)
            self.kill()

        elif pg.time.get_ticks() - self.spawn_time > self.duration:
            PoisonPuddle(self.game, self.pos)
            self.kill()
        

    def apply_dot_effect(self):
        dot_effect = DotEffect(self.game, self.target, 5, 5000, 500)
        self.target.apply_dot(dot_effect)


class PoisonPuddle(pg.sprite.Sprite):
    def __init__(self, game, pos):
        super().__init__(game.all_sprites, game.mob_bullets)
        self.game = game
        self.image = game.mob_weapon_images['poison_puddle']
        self.rect = self.image.get_rect(center=pos)
        self.hit_rect = self.rect
        self.pos = vec(pos)
        self.damage = POISON_DAMAGE
        self.last_damage_time = 0
        self.damage_interval = 500
        self.spawn_time = pg.time.get_ticks()
        self.duration = 3000
        self.target = game.player

    def update(self):
        if pg.time.get_ticks() - self.spawn_time > self.duration:
            self.kill()

        if self.rect.colliderect(self.target.rect):
            now = pg.time.get_ticks()
            if now - self.last_damage_time > self.damage_interval:
                self.target.health -= self.damage
                self.last_damage_time = now
   

class RobotMob(Mob):
    def __init__(self, game, x, y):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs, game.boss
        super().__init__(game, x, y, 'robot_mob')
        self.engage_radius = 600
        self.last_shot = 0
    
    def pulse_shock(self):
        now = pg.time.get_ticks()
        if now - self.last_shot > 3000:  
            player_pos = self.target.pos
            mob_pos = self.pos
            mob_to_player = player_pos - mob_pos
            distance_to_player = mob_to_player.length()
            #dir = vec(1, 0).rotate(-self.rot)
            
            if distance_to_player < self.engage_radius:
                # Launch the poison ball towards the player
                mob_to_player.normalize_ip()
                mob_velocity = mob_to_player * ELECTRO_SHOCK_SPEED
                # Create a new poison ball at the current position
                new_electro_shock = ElectroShock(self.game, mob_pos, ELECTRO_SHOCK_DAMAGE)
                
                new_electro_shock.vel = mob_velocity
                self.last_shot = now  # Update the last_shot time
        

    def update(self):
        super().update()
        self.pos += self.vel * self.game.dt
        player_dist = self.target.pos - self.pos
        if player_dist.length_squared() < self.engage_radius**2:
           self.pulse_shock()

class ElectroShock(pg.sprite.Sprite):
    def __init__(self, game, pos, damage):
        self._layer = BULLET_LAYER
        self.groups = game.all_sprites, game.mob_bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.mob_weapon_images['electro_shock']
        self.rect = self.image.get_rect()
        self.hit_rect = self.rect
        self.pos = vec(pos)
        self.rect.center = pos
        self.rot = 0
        self.damage = damage
        self.duration = 7000  # Duration of the poison ball in milliseconds
        self.spawn_time = pg.time.get_ticks()  # Track the spawn time
        self.engage_radius = 250  # Engage radius in pixels
        self.wall = game.walls
        self.target = game.player  # Set the target as the player
        # Calculate initial direction and velocity towards the player's position at creation
        direction = (self.target.pos - self.pos).normalize()  # Normalize to get direction
        self.velocity = direction * ELECTRO_SHOCK_SPEED  # Maintain this velocity



    def update(self):
        # Move in the initial direction towards the player's position at creation
        self.pos += self.velocity * self.game.dt
        self.rect.center = self.pos
        #DotEffect(self.game, self.target, 5, 5000, 500)
        if pg.sprite.spritecollideany(self,self.game.walls):
            self.kill()
        if pg.time.get_ticks() - self.spawn_time > self.duration:
            self.kill()


class MantisMob(Mob):
    def __init__(self, game, x, y):
        super().__init__(game, x, y, 'mantis_mob')
        self.camouflage_cooldown = 6000  # 6 seconds
        self.last_camouflage_time = 0
        self.is_camouflaged = True
        self.camouflage_duration = 12000  # 12 seconds
        self.last_strike_time = 0
        self.strike_pause_duration = 1000  # 1 second
        self.is_striking = False
        self.target = game.player
        self.strike_damage = 35

    def camouflage(self):
        current_time = pygame.time.get_ticks()
        if current_time - self.last_camouflage_time > self.camouflage_cooldown and not self.is_camouflaged:
            self.is_camouflaged = True
            self.last_camouflage_time = current_time

        if self.is_camouflaged:
            if current_time > self.camouflage_duration:
                self.is_camouflaged = False
                self.last_camouflage_time = current_time
               
    def mantis_strike(self):
        current_time = pygame.time.get_ticks()
        player_pos = self.target.pos
        mob_pos = self.pos
        mob_to_player = player_pos - mob_pos
        distance_to_player = mob_to_player.length()

        if distance_to_player < 40 and not self.is_striking:  # Within range and not already striking
            mob_to_player.normalize_ip()
            mob_velocity = mob_to_player * 400
            self.vel = mob_velocity
            self.is_striking = True  # Enter lunging state
            self.avoid_walls()  # Avoid walls during lunge
            if pg.sprite.collide_rect(self, self.target):            
                self.game.player.health -= self.strike_damage
        elif self.is_striking:  # If already striking, check if it's time to reset velocity
            if current_time - self.last_strike_time > self.strike_pause_duration:
                self.vel = vec(0, 0)  # Stop moving after lunge pause
                self.is_striking = False  # Reset lunging state
                self.last_strike_time = current_time  # Reset strike cooldown

    def update(self):
        super().update()
        self.camouflage()        
        player_dist = self.target.pos - self.pos
        if player_dist.length_squared() < ENGAGE_RADIUS**2:
            if random.random() < 0.002:
                choice(self.game.zombie_moan_sounds).play()
            self.rot = player_dist.angle_to(vec(1, 0))
            if self.is_camouflaged:
                self.image = pg.transform.rotate(self.game.mob_img['camo_mantis'], self.rot)
            else:
                self.image = pg.transform.rotate(self.game.mob_img['mantis_mob'], self.rot)            
            self.rect = self.image.get_rect()
            self.rect.center = self.pos
            self.acc = vec(1, 0.01).rotate(-self.rot)
            self.avoid_mobs()
            self.acc.scale_to_length(self.speed)
            self.acc += self.vel * -1
            self.vel += self.acc * self.game.dt
            self.pos += self.vel * self.game.dt + 0.5 * self.acc * self.game.dt ** 2
            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.game.walls, 'y')
            self.rect.center = self.hit_rect.center
        if player_dist.length_squared() < 40:
            self.mantis_strike()
        if self.health <= 0:
            choice(self.game.zombie_hit_sounds).play()
            self.game.map_img.blit(self.game.splat, self.pos - vec(32, 32))
            self.kill()
            self.game.score += 50

class ZombieDogMob(Mob):
    def __init__(self, game, x, y):
        super().__init__(game, x, y, 'zombie_dog_mob')
        self.last_spawn = pg.time.get_ticks()  # Initialize last_spawn with the current time
        self.last_dodge = 0  # Initialize last_throw with 0 or current time
        self.speed = 110

    def dodge_bullet(self):
        now = pg.time.get_ticks()
        if now - self.last_dodge > 3000:            
            # Example dodge logic: move the mob to a new position
            dodge_distance = 20  # Distance to dodge
            self.vel = vec(0, dodge_distance)  # Move vertically by dodge_distance
            self.pos += self.vel  # Update the position
            self.last_dodge = now

    def update(self):
        super().update()
        if pg.sprite.spritecollideany(self, self.game.bullets):
            self.dodge_bullet()
        self.speed = 110
        self.dodge_bullet()
        

From settings import WEAPONS
import copy

def build_weapons():
    weapons = copy.deepcopy(BASE_WEAPONS)

    for node_id, rank in PLAYER_TALENTS.items():
        if rank > 0:
            node = TALENT_NODES[node_id]
            node["effect"](rank, weapons["pistol"])  # apply to pistol stats
            # later you’ll map node_id → correct weapon

    return weapons




TALENT_NODES = {
    "pistol_1_1": {
        "name": "Damage Boost",
        "max_rank": 3,
        "effect": lambda rank, stats: stats.update(
            {"bullet_damage": stats["bullet_damage"] + 5 * rank}
        )
    },
    "pistol_1_2": {
        "name": "Reload Speed",
        "max_rank": 3,
        "effect": lambda rank, stats: stats.update(
            {"reload_time": stats.get("reload_time", 1000) * (1 - 0.1 * rank)}
        )
    },
    "pistol_1_3": {
        "name": "Longer Shots",
        "max_rank": 3,
        "effect": lambda rank, stats: stats.update(
            {"bullet_lifetime": stats["bullet_lifetime"] * (1 + 0.1 * rank)}
        )
    },
    "pistol_1_4": {
        "name": "Critical Chance",
        "max_rank": 3,
        "effect": lambda rank, stats: stats.update(
            {"crit_chance": stats.get("crit_chance", 0) + 5 * rank}
        )
    },
    "pistol_1_5": {
        "name": "Triple Shot",
        "max_rank": 1,
        "effect": lambda rank, stats: stats.update(
            {"bullet_count": 3 if rank > 0 else stats["bullet_count"]}
        )
    },
    # … and so on for 1_6 through 1_10

PLAYER_TALENTS = {
    "pistol_1_1": 0,
    "pistol_1_2": 0,
    "pistol_1_3": 0,
    "pistol_1_4": 0,
    "pistol_1_5": 0,
    # … etc
}


    

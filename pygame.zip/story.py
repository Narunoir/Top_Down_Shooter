STORY_SCRIPT = [
    'In the sleepy town of Braindead, USA, a mysterious virus has turned the student body into flesh-eating zombies.',
    'But amidst the chaos, a group of survivors must band together to uncover the truth behind the outbreak and save their school from becoming a zombie-infested hellhole.',
    'After escaping the high school, Jake and his friends find themselves at the local mall, where a toxic spill has turned shoppers into mutated monsters.',
    'As the mutants multiply, the group must fight to survive the night and escape the mall before it\'s too late.',
    'But the horror doesn\'t end there. A rogue AI named "The Overmind" has taken control of the city\'s robots, turning them against their human creators.',
    'As the robots rise up, the group must fight to take down The Overmind and restore order to the city.',
    'But that\'s not all. A mysterious curse has turned the camp\'s staff into bloodthirsty zombies.',
    'As the campers fight to survive, they uncover a dark secret behind the camp\'s history.',
    'With the help of The Ranger, a mysterious figure who has been helping them throughout their journey, Jake and his friends must use all their skills and knowledge to defeat the villains and save the world from destruction.',
]
import pygame as pg
import pytmx
from settings import *

def collide_hit_rect(one, two):
    return one.hit_rect.colliderect(two.rect)

class Map:
    def __init__(self, filename):
        self.data = []
        with open(filename, 'rt') as f:
            for line in f:
                self.data.append(line.strip())

        self.tilewidth = len(self.data[0])
        self.tileheight = len(self.data)
        self.width = self.tilewidth * TILESIZE
        self.height = self.tileheight * TILESIZE

class TiledMap:
    def __init__(self, filename):
        tm = pytmx.load_pygame(filename, pixelalpha=True)
        self.width = tm.width * tm.tilewidth
        self.height = tm.height * tm.tileheight
        self.tmxdata = tm
        self.grid = self.build_grid()

    def build_grid(self):
        grid = []
        for y in range(self.tmxdata.height):
            row = []
            for x in range(self.tmxdata.width):
                tile = self.tmxdata.get_tile_gid(x, y, 0)
                row.append(tile)
            grid.append(row)
        return grid

    def render(self, surface):
        ti = self.tmxdata.get_tile_image_by_gid
        for layer in self.tmxdata.visible_layers:
            if isinstance(layer, pytmx.TiledTileLayer):
                for x, y, gid, in layer:
                    tile = ti(gid)
                    if tile:
                        surface.blit(tile, (x * self.tmxdata.tilewidth,
                                            y * self.tmxdata.tileheight))

    def make_map(self):
        temp_surface = pg.Surface((self.width, self.height))
        self.render(temp_surface)
        return temp_surface

class Camera:
    def __init__(self, width, height):
        self.camera = pg.Rect(0, 0, width, height)
        self.width = width
        self.height = height

    def apply(self, entity):
        offset = (int(self.camera.x), int(self.camera.y))
        return entity.rect.move(offset)

    def apply_rect(self, rect):
        return rect.move(self.camera.topleft)

    def update(self, target):
        x = -target.rect.centerx + int(WIDTH / 2)
        y = -target.rect.centery + int(HEIGHT / 2)

        # limit scrolling to map size
        x = min(0, x)  # left
        y = min(0, y)  # top
        x = max(-(self.width - WIDTH), x)  # right
        y = max(-(self.height - HEIGHT), y)  # bottom
        self.camera = pg.Rect(x, y, self.width, self.height)

class TalentBox:
    def __init__(self, x, y, size, label):
        self.rect = pygame.Rect(x, y, size, size)
        self.level = 0  # Counter from 0 to 10
        self.font = pygame.font.SysFont(None, 24)
        self.label = label  # Store the label text

    def draw(self, surface):
        # Draw box
        color = HIGHLIGHT_COLOR if self.level > 0 else BOX_COLOR
        pygame.draw.rect(surface, color, self.rect)

        # Draw label text above the box
        label_text = self.font.render(self.label, True, TEXT_COLOR)
        label_rect = label_text.get_rect(center=(self.rect.centerx, self.rect.top - 12))
        surface.blit(label_text, label_rect)

        # Draw counter text centered under the box
        counter_text = self.font.render(str(self.level), True, TEXT_COLOR)
        counter_rect = counter_text.get_rect(center=(self.rect.centerx, self.rect.bottom + 12))
        surface.blit(counter_text, counter_rect)

    def handle_click(self, pos):
        if self.rect.collidepoint(pos):
            if self.level < 10:
                self.level += 1





    
